<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class City extends Model {	

	protected $fillable = ['title'];

	public function scopeSearch($query,$id) {
		$query->select('cities.id as city_id','cities.title as city_name','cities.type as type','provinces.title as province','cities.postal_code');
		$query->leftJoin('provinces', 'provinces.id', '=', 'cities.province_id');
		$query->where('cities.id', $id);
	}
}