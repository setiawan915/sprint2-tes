<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Province extends Model {	

	protected $fillable = ['title'];

	public function scopeSearch($query,$id) {
		$query->select('provinces.id as province_id','provinces.title as province');
		$query->where('id', $id);
	}

}