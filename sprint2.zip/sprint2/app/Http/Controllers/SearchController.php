<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Province;
use App\Models\City;
use Ixudra\Curl\Facades\Curl;

class SearchController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    function province(Request $req){
        $dataFrom = ENV('DATA_FROM');

        //cek param
        $checkParam=cparam($req,['id','token_key']);
        if($checkParam!==true) return $checkParam;

        //cek token key
        $user=checkToken($req);
        if(empty($user->id)) return $user;

        $id = $req->id;
        if($dataFrom=='database'){
            $respProvince = Province::search($id)->get();
        }else{
            $key = ENV('KEY_API');
            $provinces = Curl::to('https://api.rajaongkir.com/starter/province')
            ->withHeader('key: '.$key)
            ->withData( array( 'id' => $id ) )
            ->get();
            $provinces = json_decode($provinces, true);
            $respProvince[] = [
                'province_id'   => $provinces['rajaongkir']['results']['province_id'],
                'province'      => $provinces['rajaongkir']['results']['province']
            ];
        }
        return appResponse($respProvince,'success');
    }

    function city(Request $req){
        $dataFrom = ENV('DATA_FROM');

        //cek param
        $checkParam=cparam($req,['id','token_key']);
        if($checkParam!==true) return $checkParam;

        //cek token key
        $user=checkToken($req);
        if(empty($user->id)) return $user;

        $id = $req->id;
        if($dataFrom=='database'){
            $resCity = City::search($id)->get();
        }else{
            $key = ENV('KEY_API');
            $city = Curl::to('https://api.rajaongkir.com/starter/city')
            ->withHeader('key: '.$key)
            ->withData( array( 'id' => $id ) )
            ->get();
            $city = json_decode($city, true);
            $resCity[] = [
                'city_id'   => $city['rajaongkir']['results']['city_id'],
                'city_name' => $city['rajaongkir']['results']['city_name'],
                'type'      => $city['rajaongkir']['results']['type'],
                'province'  => $city['rajaongkir']['results']['province'],
                'postal_code'=>$city['rajaongkir']['results']['postal_code'],
            ];
        }
        return appResponse($resCity,'success');
    }
}
