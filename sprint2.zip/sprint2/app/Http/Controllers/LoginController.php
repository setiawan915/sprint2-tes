<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class LoginController extends Controller
{

    function handler(Request $request){
        //print_r(encryptPassword('admin')).die;
    	$username = $request->username;
        $password = $request->password;
        $password = encryptPassword($password);
        $data = User::where('username',$username)->first();
        if(count($data) > 0){
            if($password!=$data->password){
                $respLogin[] = ['Password wrong!'];
                $status = 'success';
            }else{
                $token_key = generateToken($username);
                $respLogin[] = [
                    'username' => $username,
                    'token_key'=> $token_key
                ];
                $status = 'success';
                $data->remember_token = $token_key;
                $data->update();
            }
        }else{
            $respLogin[] = ['User not registered!'];
            $status = 'blocked';
        }
        return appResponse($respLogin,$status);
    }
}
